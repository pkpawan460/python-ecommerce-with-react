import React, { Component } from 'react'

class Categories extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return (
            <div className="main">
                <h1>Category</h1>
            </div>
         );
    }
}
 
export default Categories;